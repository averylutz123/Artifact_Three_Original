package com.zybooks.averylutzeventtracker;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

public class EventDialogFragment extends DialogFragment {

    // Host activity must implement
    public interface OnEventEnteredListener {
        void onEventEntered(String event);
    }

    private OnEventEnteredListener mListener;

    @Override
    public AlertDialog onCreateDialog(Bundle savedInstanceState) {

        final EditText eventEditText = new EditText(getActivity());
        eventEditText.setInputType(InputType.TYPE_CLASS_TEXT);
        eventEditText.setMaxLines(1);

        return new AlertDialog.Builder(getActivity())
                .setTitle(R.string.event)
                .setView(eventEditText)
                .setPositiveButton(R.string.create, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        String subject = eventEditText.getText().toString();
                        mListener.onEventEntered(subject.trim());
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .create();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mListener = (OnEventEnteredListener) context;
    }
}