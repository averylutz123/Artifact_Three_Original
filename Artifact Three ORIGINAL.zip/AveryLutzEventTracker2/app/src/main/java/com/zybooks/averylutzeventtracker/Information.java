package com.zybooks.averylutzeventtracker;

public class Information {

    private long mId;
    private String mName;
    private String mDate;
    private String mTime;
    private String mNotes;
    private String mEvent;


    public String getName() {
        return mName;
    }
    public void setName(String name) {
        this.mName = name;
    }

    public long getId() { return mId; }
    public void setId(long id) {
        mId = id;
    }

    public String getDate() { return mDate; }
    public void setDate(String date) { this.mDate = date; }

    public String getTime() {
        return mTime;
    }
    public void setTime(String time) {
        this.mTime = time;
    }

    public String getNotes() { return mNotes; }
    public void setNotes(String notes) {
        this.mNotes = notes;
    }

    public String getEvent() {
        return mEvent;
    }
    public void setEvent(String event) {
        this.mEvent = event;
    }

}
