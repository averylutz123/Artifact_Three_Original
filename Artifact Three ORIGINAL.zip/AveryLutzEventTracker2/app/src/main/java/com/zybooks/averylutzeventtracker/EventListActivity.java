package com.zybooks.averylutzeventtracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class EventListActivity extends AppCompatActivity
        implements EventDialogFragment.OnEventEnteredListener {

    private EventDatabase mEventDb;
    private EventAdapter mEventAdapter;
    private RecyclerView mRecyclerView;
    private int[] mEventColors;
    private String mUsername;
    private String mUserPermission;

    @Override
    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        mEventColors = getResources().getIntArray(R.array.EventColors);

        // Singleton
        mEventDb = EventDatabase.getInstance(getApplicationContext());

        Intent intent = getIntent();
        mUsername = intent.getStringExtra("username");


        mRecyclerView = findViewById(R.id.subjectRecyclerView);

        // Create 2 grid layout columns
        RecyclerView.LayoutManager gridLayoutManager =
                new GridLayoutManager(getApplicationContext(), 2);
        mRecyclerView.setLayoutManager(gridLayoutManager);

        // Shows the available subjects
        mEventAdapter = new EventAdapter(loadSubjects());
        mRecyclerView.setAdapter(mEventAdapter);
    }

    @Override
    public void onEventEntered (String event){
        // Returns subject entered in the SubjectDialogFragment dialog
        if (event.length() > 0) {
            Event sub = new Event(event);
            if (mEventDb.addEvent(sub, mUsername)) {
                // TODO: add subject to RecyclerView
                Toast.makeText(this, "Added " + event, Toast.LENGTH_SHORT).show();
            } else {
                String message = getResources().getString(R.string.event_exists, event);
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void addEventClick (View view){
        // Prompt user to type new subject
        FragmentManager manager = getSupportFragmentManager();
        EventDialogFragment dialog = new EventDialogFragment();
        dialog.show(manager, "subjectDialog");
    }

    private List<Event> loadSubjects() {
        return mEventDb.getEvents(EventDatabase.SubjectSortOrder.UPDATE_DESC, mUsername);
    }

    private class SubjectHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {

        private Event mEvent;
        private TextView mTextView;

        public SubjectHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.recycler_view_items, parent, false));
            itemView.setOnClickListener(this);
            mTextView = itemView.findViewById(R.id.eventTextView);
        }

        public void bind(Event event, int position) {
            mEvent = event;
            mTextView.setText(event.getName());

            // Make the background color dependent on the length of the subject string
            int colorIndex = event.getName().length() % mEventColors.length;
            mTextView.setBackgroundColor(mEventColors[colorIndex]);
        }

        @Override
        public void onClick(View view) {
            // Start QuestionActivity, indicating what subject was clicked
            Intent intent = new Intent(EventListActivity.this, EventInformationActivity.class);
            intent.putExtra(EventInformationActivity.EXTRA_EVENT, mEvent.getName());
            intent.putExtra("username", mUsername);
            intent.putExtra("permission", mUserPermission);
            startActivity(intent);

        }
    }

    private class EventAdapter extends RecyclerView.Adapter<SubjectHolder> {

        private List<Event> mEventList;

        public EventAdapter(List<Event> events) {
            mEventList = events;
        }

        @Override
        public SubjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
            return new SubjectHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(SubjectHolder holder, int position) {
            holder.bind(mEventList.get(position), position);
        }

        @Override
        public int getItemCount() {
            return mEventList.size();
        }
    }

}