package com.zybooks.averylutzeventtracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.widget.Button;
import android.os.Bundle;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class Permissions extends AppCompatActivity {
    private int SMS_PERMISSION_CODE = 0;
    private String userPermission;
    private String mUsername;
    private UserAccount mUserAccount;
    private EventDatabase mEventDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permissions);

        Button okayButton = findViewById(R.id.okayButton);
        Button notNowButton = findViewById(R.id.notNowButton);

        mEventDb = EventDatabase.getInstance(getApplicationContext());

        Intent intent = getIntent();
        mUsername = intent.getStringExtra("username");


        // USER GIVES PERMISSION TO RECEIVE NOTIFICATION!!
        okayButton.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(Permissions.this,
                    Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED){
                Toast.makeText(Permissions.this, "You have already granted permission!", Toast.LENGTH_SHORT).show();
            }
            else{
                requestSMSPermission();
            }

        });

        // USER DENIES PERMISSION TO RECEIVE NOTIFICATION!!!!!
        notNowButton.setOnClickListener(v -> new AlertDialog.Builder(Permissions.this)
                .setTitle("Permission Needed")
                .setMessage("We would like to send a notification on the day an event is scheduled." +
                        "Are you sure you sure you do not want to be notified?")
                .setPositiveButton("I am sure", (dialog, which) -> {
                    userPermission = "no";

                    // Update existing information
                    mUserAccount = mEventDb.addPermission(mUsername, userPermission);
                    mEventDb.updateUserAccount(mUserAccount);


                    Intent intent1 = new Intent(getApplicationContext(), EventListActivity.class);
                    intent1.putExtra("username", mUsername);
                    startActivity(intent1);

                })
                .setNegativeButton("cancel", (dialog, which) -> dialog.dismiss())
                .create().show());


    }
    private void requestSMSPermission () {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
            new AlertDialog.Builder(this)
                    .setTitle("Permission Needed")
                    .setMessage("This permission is required to send a notificaiton on the day an event is scheduled")
                    .setPositiveButton("Ok", (dialog, which) -> ActivityCompat.requestPermissions(Permissions.this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE))
                    .setNegativeButton("Not Now", (dialog, which) -> dialog.dismiss())
                    .create().show();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this, "Permission GRANTED", Toast.LENGTH_SHORT).show();
                userPermission = "yes";

                mUserAccount = mEventDb.addPermission(mUsername, userPermission);
                mEventDb.updateUserAccount(mUserAccount);

                Intent intent = new Intent(getApplicationContext(), EventListActivity.class);
                intent.putExtra("username", mUsername);
                startActivity(intent);
            }
            else{
                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
            }
        }
    }


}

