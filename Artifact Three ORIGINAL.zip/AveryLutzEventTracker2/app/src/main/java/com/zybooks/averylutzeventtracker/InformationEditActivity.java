package com.zybooks.averylutzeventtracker;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class InformationEditActivity extends AppCompatActivity {

    public static final String EXTRA_INFORMATION_ID = "com.zybooks.averylutzeventtracker.information_id";
    public static final String EXTRA_EVENT = "com.zybooks.averylutzeventtracker.event";

    private EditText mEventName;
    private EditText mEventDate;
    private EditText mEventTime;
    private EditText mEventNotes;

    private EventDatabase mEventDb;
    private long mInformationId;
    private Information mInformation;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information_edit);

        mEventName = findViewById(R.id.eventNameEdit);
        mEventDate = findViewById(R.id.eventDateEdit);
        mEventTime = findViewById(R.id.eventTimeEdit);
        mEventNotes = findViewById(R.id.eventNotesEdit);

        mEventDb = EventDatabase.getInstance(getApplicationContext());

        // Get information ID from InformationActivity
        Intent intent = getIntent();
        mInformationId = intent.getLongExtra(EXTRA_INFORMATION_ID, -1);


        if (mInformationId == -1) {
            // Add new information
            mInformation = new Information();
            setTitle(R.string.add_information);
        }
        else {
            // Update existing information
            mInformation = mEventDb.getInformation(mInformationId);
            mEventName.setText(mInformation.getName());
            mEventDate.setText(mInformation.getDate());
            mEventTime.setText(mInformation.getTime());
            mEventNotes.setText(mInformation.getNotes());
            setTitle(R.string.update_information);
        }

        String event = intent.getStringExtra(EXTRA_EVENT);
        mInformation.setEvent(event);
    }

    public void saveButtonClick(View view) {

        mInformation.setName(mEventName.getText().toString());
        mInformation.setDate(mEventDate.getText().toString());
        mInformation.setTime(mEventTime.getText().toString());
        mInformation.setNotes(mEventNotes.getText().toString());


        if (mInformationId == -1) {
            // New information
            mEventDb.addInformation(mInformation);
        } else {
            // Existing information
             mEventDb.updateInformation(mInformation);
        }

        // Send back information ID
        Intent intent = new Intent();
        intent.putExtra(EXTRA_INFORMATION_ID, mInformation.getId());
        setResult(RESULT_OK, intent);
        finish();
    }
}