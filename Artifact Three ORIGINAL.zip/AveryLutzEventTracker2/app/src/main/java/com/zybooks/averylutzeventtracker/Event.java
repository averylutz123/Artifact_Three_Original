package com.zybooks.averylutzeventtracker;

public class Event {

    private String mUsername;
    private String mName;
    private long mUpdateTime;

    public Event() {}

    public Event(String name) {
        mName = name;
        mUpdateTime = System.currentTimeMillis();
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getUsername(String enteredName) {
        mUsername = enteredName;
        return mUsername; }

    public void setUsername(String username) { mUsername = username; }

    public long getUpdateTime() {
        return mUpdateTime;
    }

    public void setUpdateTime(long updateTime) {
        mUpdateTime = updateTime;
    }

}