package com.zybooks.averylutzeventtracker;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class EventInformationActivity extends AppCompatActivity {

    private final int REQUEST_CODE_NEW_INFORMATION = 0;
    private final int REQUEST_CODE_UPDATE_INFORMATION = 1;

    public static final String EXTRA_EVENT = "com.zybooks.averylutzeventtracker.event";

    private EventDatabase mEventDb;
    private Information mDeletedInformation;
    private UserAccount mUserAccount;
    private String mEvent;
    private List<Information> mInformationList;
    private TextView mEventName;
    private TextView mEventDate;
    private TextView mEventTime;
    private TextView mEventNotes;
    private Button mAddEventButton;
    private int mCurrentInformationIndex;
    private String mUsername;
    private String mUserPermission;
    private String date;
    private String eventName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_information);

        // Hosting activity provides the subject of the informations to display
        Intent intent = getIntent();
        mEvent = intent.getStringExtra(EXTRA_EVENT);


        Intent intentFromList = getIntent();
        mUserPermission = intentFromList.getStringExtra("permission");
        mUsername = intentFromList.getStringExtra("username");


        // Load event information
        mEventDb = EventDatabase.getInstance(getApplicationContext());
        mInformationList = mEventDb.getInformationGroup(mEvent);

        mEventName = findViewById(R.id.eventNameEdit);
        mEventDate = findViewById(R.id.eventDateEdit);
        mEventTime = findViewById(R.id.eventTimeEdit);
        mEventNotes = findViewById(R.id.eventNotesEdit);
        mAddEventButton = findViewById(R.id.addEventButton);

        findPermission();
        // Show first information
        showInformation(0);
    }

    @Override
    protected void onStart() {
        super.onStart();

        // Are there informations to display?
        if (mInformationList.size() == 0) {
            updateAppBarTitle();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        // Inflate menu for the app bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.event_menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Determine which app bar item was chosen
        switch (item.getItemId()) {
            case R.id.edit:
                editInformation();
                return true;
            case R.id.delete:
                deleteInformation();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }

    public void findPermission(){
        mUserAccount = mEventDb.getUserAccount(mUsername);
        mUserPermission = mUserAccount.getPermission();
    }



    public void addInformationButtonClick(View view) {
        addInformation();
    }

    private void updateAppBarTitle() {

        // Display subject and number of informations in app bar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            String title = mEvent;
            setTitle(title);
        }
    }

    private void addInformation() {
        Intent intent = new Intent(this, InformationEditActivity.class);
        intent.putExtra(InformationEditActivity.EXTRA_EVENT, mEvent);
        startActivityForResult(intent, REQUEST_CODE_NEW_INFORMATION);
    }


    private void editInformation() {
        if (mCurrentInformationIndex >= 0) {
            Intent intent = new Intent(this, InformationEditActivity.class);
            intent.putExtra(EXTRA_EVENT, mEvent);
            long informationId = mInformationList.get(mCurrentInformationIndex).getId();
            intent.putExtra(InformationEditActivity.EXTRA_INFORMATION_ID, informationId);
            startActivityForResult(intent, REQUEST_CODE_UPDATE_INFORMATION);
        }
    }

    private void deleteInformation() {
        if (mCurrentInformationIndex >= 0) {
            // Save question in case user undoes delete
            mDeletedInformation = mInformationList.get(mCurrentInformationIndex);
            mEventDb.deleteInformation(mDeletedInformation.getId());
            mInformationList.remove(mCurrentInformationIndex);

            if (mInformationList.size() == 0) {
                // No questions left to show
                mCurrentInformationIndex = -1;
                updateAppBarTitle();
            }
            else {
                showInformation(mCurrentInformationIndex);
            }

            Toast.makeText(this, R.string.question_deleted, Toast.LENGTH_SHORT).show();
        }
    }


    private void showInformation(int informationIndex) {

        // Show information at the given index
        if (mInformationList.size() > 0) {
            if (informationIndex < 0) {
                informationIndex = mInformationList.size() - 1;
            } else if (informationIndex >= mInformationList.size()) {
                informationIndex = 0;
            }

            mCurrentInformationIndex = informationIndex;
            updateAppBarTitle();

            Information information = mInformationList.get(mCurrentInformationIndex);
            mEventName.setText(information.getName());
            mEventDate.setText(information.getDate());
            mEventTime.setText(information.getTime());
            mEventNotes.setText(information.getNotes());
        }
        else {
            // No informations yet
            mCurrentInformationIndex = -1;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == REQUEST_CODE_NEW_INFORMATION) {
            // Get added information
            long informationId = data.getLongExtra(InformationEditActivity.EXTRA_INFORMATION_ID, -1);
            Information newInformation = mEventDb.getInformation(informationId);

            // Add newly created information to the information list and show it
            mInformationList.add(newInformation);
            showInformation(mInformationList.size() - 1);
            date = newInformation.getDate();
            eventName = newInformation.getName();
            if(mUserPermission.equals("yes")){

                //THIS IS WHERE We send Message!!!!
                String userPhoneNumber = "15555215554";
                String senderPhoneNumber = "5551124816";
                String message = "The event " + eventName + " has been scheduled for " + date + "!!!";
                SmsManager mySmsManager = SmsManager.getDefault();
                mySmsManager.sendTextMessage(userPhoneNumber,senderPhoneNumber,message,null,null);

            }

            Toast.makeText(this, R.string.information_added, Toast.LENGTH_SHORT).show();
        }
        else if (resultCode == RESULT_OK && requestCode == REQUEST_CODE_UPDATE_INFORMATION) {
            // Get updated information
            long informationId = data.getLongExtra(InformationEditActivity.EXTRA_INFORMATION_ID, -1);
            Information updatedInformation = mEventDb.getInformation(informationId);

            // Replace current information in information list with updated information
            Information currentInformation = mInformationList.get(mCurrentInformationIndex);
            currentInformation.setName(updatedInformation.getName());
            currentInformation.setDate(updatedInformation.getDate());
            currentInformation.setTime(updatedInformation.getTime());
            currentInformation.setNotes(updatedInformation.getNotes());
            showInformation(mCurrentInformationIndex);

            Toast.makeText(this, R.string.information_updated, Toast.LENGTH_SHORT).show();
        }
    }
    
}