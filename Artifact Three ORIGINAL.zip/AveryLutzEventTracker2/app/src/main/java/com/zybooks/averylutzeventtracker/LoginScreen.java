package com.zybooks.averylutzeventtracker;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

import java.util.List;


public class LoginScreen extends AppCompatActivity {

    // Create variables that will be utilized for the login process.
    private EditText mUsername;
    private EditText mPassword;
    private Button mLoginButton;
    private Button mCreateButton;
    private EventDatabase mEventDb;
    private UserAccount mUserAccount;
    private List<UserAccount> mUserAccountList;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);

        // Set the created variables to values entered by user in XML file.
        mUsername = findViewById(R.id.enteredUsername);
        mPassword = findViewById(R.id.enteredPassword);
        mLoginButton = findViewById(R.id.loginButton);
        mCreateButton = findViewById(R.id.createAccountButton);

        mEventDb = EventDatabase.getInstance(getApplicationContext());
        mUserAccountList = mEventDb.getAccounts();

        // Active Create Account Button with click listener.
        mCreateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mUserAccount = new UserAccount();
                mUserAccount.setUsername(mUsername.getText().toString());
                mUserAccount.setPassword(mPassword.getText().toString());

                if (mUsername.getText().toString().isEmpty() ||mPassword.getText().toString().isEmpty()){
                    Toast.makeText(LoginScreen.this, R.string.enter_fields, Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean checkUser = mEventDb.checkUsername(mUsername.getText().toString());
                    if(checkUser == false){
                        Boolean insert = mEventDb.insertUserAccount(mUserAccount);
                        if(insert == true){
                            Toast.makeText(LoginScreen.this, R.string.successful_account, Toast.LENGTH_SHORT).show();
                            mUserAccountList.add(mUserAccount);
                        //    mEventDb.addUserToEventTable(mUsername.getText().toString());
                            username = mUsername.getText().toString();

                            Intent intent = new Intent(getApplicationContext(), Permissions.class);
                            intent.putExtra("username", username);
                            startActivity(intent);
                        }
                        else{
                            Toast.makeText(LoginScreen.this, R.string.fail_account, Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(LoginScreen.this, R.string.user_exists, Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // Activate Login Button with click listener.
        mLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mUserAccount = new UserAccount();
                mUserAccount.setUsername(mUsername.getText().toString());
                mUserAccount.setPassword(mPassword.getText().toString());


                if (mUsername.getText().toString().isEmpty() ||mPassword.getText().toString().isEmpty()){
                    Toast.makeText(LoginScreen.this, R.string.enter_fields, Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean checkUserPass = mEventDb.checkUsernamePassword(mUsername.getText().toString(), mPassword.getText().toString());
                    if(checkUserPass == true){
                        Toast.makeText(LoginScreen.this, R.string.login_success, Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), EventListActivity.class);
                        username = mUsername.getText().toString();
                        intent.putExtra("username", username);
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(LoginScreen.this, R.string.login_fail, Toast.LENGTH_SHORT).show();
                    }

                }

            }
        });


    }
}
